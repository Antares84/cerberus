<?php
	if(file_exists($cfg["SPONSORS_LOC"].'sponsors.php')){include_once($cfg["SPONSORS_LOC"].'sponsors.php');}
	else{echo 'Failed to load CMS Sponsors';}
?>