<?php
	echo '<div id="title" class="sTitle">Sponsors</div>';
	echo '<div id="sidebar-left" class="sContent">';
		echo '<p><a href="http://stoacademy.com" target="_blank">STO Academy</a></p>';
		echo '<p><a href="http://auth.startrekonline.com" target="_blank">STO Gateway</a></p>';
	echo '</div>';
?>