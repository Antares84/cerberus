function NewTicket(){
	document.getElementById("display").innerHTML = "" +
		"Please select the type of trouble you are having.<br><br>" +
		"<select id = 'category' name='category' length='51'>" +
		"SELECT type from categories<br><br>";
	document.getElementById("display").innerHTML +=  "</select> " +
		"Choose the importance of this ticket.<br><br><br>" +
		"<select id='priority' name='priority' length='31'>";
	document.getElementById("display").innerHTML +=  "</select><br> " +
		"Choose Department.<br><br><br>" +
		"<select id='department' name='department' length='31'>";
	document.getElementById("display").innerHTML += "</select> " +
		"<br>This ticket will be logged under your current username and email in the system. Please check back periodically to check  the status. <br><br>" +
		"Enter a Subject for this Ticket <input type='text' id='subject' size='60'><br />" +
		"Description of the Problem<br /> <textarea cols='50' id='description' rows='6'> </textarea>" +
		"<br><br />" +
		"<input type='submit' value='Submit Ticket' onclick='SubmitTicket()'>";

	$.ajax({
		url : 'assets/plugins/Ticket_System/scripts/php/getTypes.php',
		type : 'POST',
		data : {},
		dataType:'json',
		success : function(data) { 
			for(var i = 0; i < data.length; i++){
				document.getElementById('category').options.add(new Option(data[i].Type, data[i].RowID))
			}
		}
	});
	$.ajax({
		url : 'assets/plugins/Ticket_System/scripts/php/getPriority.php',
		type : 'POST',
		data : {},
		dataType:'json',
		success : function(data) { 
			for(var i = 0; i < data.length; i++){
				document.getElementById('priority').options.add(new Option(data[i].Level, data[i].RowID))
			}
		}
	});
	$.ajax({
		url : 'assets/plugins/Ticket_System/scripts/php/getDepartments.php',
		type : 'POST',
		data : {},
		dataType:'json',
		success : function(data) {
			console.log(data);
			for(var i = 0; i < data.length; i++){
				document.getElementById('department').options.add(new Option(data[i].Type, data[i].RowID))
			}
		}
	});
}
function SubmitTicket(){
	$.ajax({
		url : 'assets/plugins/Ticket_System/scripts/php/submitTicket.php',
		type : 'POST',
		data : { subject:document.getElementById("subject").value,description:document.getElementById("description").value,userName:userName,category:document.getElementById("category").options[document.getElementById("category").selectedIndex].value,priority:document.getElementById("priority").options[document.getElementById("priority").selectedIndex].value,department:document.getElementById("department").options[document.getElementById("department").selectedIndex].value},
		dataType:'json',
		success : function(data) { 
			if(data == "1"){
				document.getElementById("display").innerHTML = "Ticket sent";
			}else{
				document.getElementById("display").innerHTML = data;
			}
		}
	});
}
function ShowTickets(){
	document.getElementById("display").innerHTML = "";
	$.ajax({
		url : 'assets/plugins/Ticket_System/scripts/php/getTickets.php',
		type : 'POST',
		data : {},////<---- change this to filter by type, you can pass category type
		dataType:'json',
		success : function(data) { 
			var ticketTable = "<table class='table'><tr><th>Submitter</th><th>Category</th><th>Priority</th><th>Subject</th><th>Department</th><th>View</th></tr>";
			for(var i = 0; i < data.length; i++){
				ticketTable += "<tr><td>" + data[i].Name + "</td><td>" + data[i].Category + "</td><td>" + data[i].Priority + "</td><td>" + data[i].Subject + "</td><td>" + data[i].Department + "</td><td><input type='button' value='View' onclick='ViewTicket(" + data[i].RowID + ")'</td></tr>";
				
			}
			ticketTable += "</table>";
			document.getElementById("display").innerHTML += ticketTable;
		}
	});
}
function ViewTicket(id){
//	alert(id);
	document.getElementById("display").innerHTML += "" +
		"Subject: " + data[i].Subject + "<br>" + "Description: " + data[i].Description + "<br />";

	$.ajax({
		url : 'assets/plugins/Ticket_System/scripts/php/getTicketInfo.php',
		type : 'POST',
		data : {},
		dataType:'json',
		success : function(data) { 
			for(var i = 0; i < data.length; i++){
				document.getElementById('category').options.add(new Option(data[i].Subject, data[i].Description))
			}
		}
	});
}