//document.write('<script src="scripts/js/login/userLogin.js"><\/script>');
//document.write('<script src="scripts/js/login/register.js"><\/script>');
//document.write('<script src="assets/plugins/Ticket_System/scripts/js/login/messages.js"><\/script>');
document.write('<script src="assets/plugins/Ticket_System/scripts/js/functions.js"><\/script>');
