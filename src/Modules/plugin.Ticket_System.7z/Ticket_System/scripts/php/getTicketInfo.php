<?php
	include 'DbClass.php';
	$db = new Db();
	$rows = $db -> select("SELECT Subject,Description FROM TicketSystem.dbo.Tickets");
	if($rows){
#		$db -> close();
		echo json_encode($rows);
	}
?>