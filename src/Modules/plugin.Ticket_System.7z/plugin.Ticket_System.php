<?php
	$cfg["WS_Tkt_Sys_Lib"]=$cfg["WS_Tkt_Sys_Loc"]."lib/";
	$cfg["WS_Tkt_Sys_Scr"]=$cfg["WS_Tkt_Sys_Loc"]."scripts/";
	echo '<link rel="stylesheet" href="'.$cfg["WS_Tkt_Sys_Lib"].'bootstrap.min.css">';
	echo '<link rel="stylesheet" href="'.$cfg["WS_Tkt_Sys_Lib"].'style.css">';
	echo '<script type="application/javascript" src="'.$cfg["WS_Tkt_Sys_Lib"].'jquery-1.11.2.min.js"></script>';
	echo '<script type="application/javascript" src="'.$cfg["WS_Tkt_Sys_Lib"].'bootstrap.min.js"></script>';
	echo '<script type="application/javascript" src="'.$cfg["WS_Tkt_Sys_Scr"].'js/includes.js"></script>';
?>