<?php
	require_once('config.php');
	/* Copyright (c) 2015 Devendra Katariya (bylancer.com) */

	if ($_GET['action'] == "get_all_msg") { get_all_msg(); } 
	if ($_GET['action'] == "chatheartbeat") { chatHeartbeat(); } 
	if ($_GET['action'] == "sendchat") { sendChat(); } 
	if ($_GET['action'] == "closechat") { closeChat(); } 
	if ($_GET['action'] == "startchatsession") { startChatSession(); } 
	if ($_GET['action'] == "typingstatus") { typingStatus(); }

	if (!isset($_SESSION['chatHistory'])) {
		$_SESSION['chatHistory'] = array();
	}

	if (!isset($_SESSION['openChatBoxes'])) {
		$_SESSION['openChatBoxes'] = array();
	}

	if (!isset($_SESSION['chatpage'])) {
		$_SESSION['chatpage'] = 1;	
	}


	get_all_msg();
	chatHeartbeat();
	chatBoxSession($chatbox);
	startChatSession();
	sendChat();
	typingStatus();
	closeChat();
	sanitize($text);

?>