<?php
	# Server IP
	$cfg["dbHost"]="127.0.0.1";

	# Server Username
	$cfg["dbUser"]="Sacred";

	# Server Password
	$cfg["dbPass"]="Platinum1520";

	# Database Connection String | DO NOT EDIT
	$cxn1 = @odbc_connect('Driver={SQL Server};Server='.$cfg["dbHost"].';',$cfg["dbUser"],$cfg["dbPass"]) or die('Database <b>0x01</b> Connection Error!<br />Website will be back online momentarily.');

	# Include WS Functions
	foreach(glob("./functions/fn.*.php") as $FuncFile){include $FuncFile;}
?>