<?php
	function typingStatus() {
		$from = $_SESSION['username'];
		$to = $_POST['to'];
		$to_id = $_POST['toid'];
		$from_id = $_SESSION['id'];
		$typing = $_POST['typing'];

		if (!isset($_SESSION['chatHistory'][$_POST['to']])) {
			$_SESSION['chatHistory'][$_POST['to']] = '';
		}

# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
		$_SESSION['chatHistory'][$_POST['to']] .= <<<EOD
		{
			"ty": "{$typing}"
		},
EOD;
		unset($_SESSION['tsChatBoxes'][$_POST['to']]);
		echo "1";
		exit(0);
	}
?>