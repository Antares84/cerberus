<?php
	function chatHeartbeat() {
		global $cxn;
		$sql = ("SELECT * FROM WS_TPL.dbo.WS_Messages WHERE to_uname = '".escData($_SESSION["username"])."' AND recd = 0 ORDER BY message_id ASC");
		$query = odbc_exec($cxn,$sql);
		$items = '';
		$chatBoxes = array();
		while ($chat = odbc_fetch_array($query)) {
			$picname = "";
			$picname2 = "";
			$query1 = ("SELECT picname,online FROM WS_TPL.dbo.WS_UserData WHERE UserID = ?");
			$stmt1 = odbc_prepare($cxn,$query1);
			$args1 = array(escData($chat["from_uname"]));
			$res1 = odbc_execute($stmt1,$args1);
			while ($info = odbc_fetch_array($stmt1)) {
				$picname = "small".$info['picname'];
				$status = $info['online'];
			}
			$query4 = ("SELECT picname FROM WS_TPL.dbo.WS_UserData WHERE UserID = ?");
			$stmt4 = odbc_prepare($cxn,$query4);
			$args4 = array(escData($_SESSION['username']));
			$res4 = odbc_execute($stmt4,$args4);
			while ($info4 = odbc_fetch_array($stmt4)) {
				$picname2 = "small".$info4['picname'];
			}
			if($picname == "small"){
				$picname = "avatar_default.png";
			}
			if($picname2 == "small"){
				$picname2 = "avatar_default.png";
			}
			if($status == "0"){
				$status = "Offline";
			}else{
				$status = "Online";
			}
			if (!isset($_SESSION['openChatBoxes'][$chat['from_uname']]) && isset($_SESSION['chatHistory'][$chat['from_uname']])) {
				$items = $_SESSION['chatHistory'][$chat['from_uname']];
			}
			$chat['message_content'] = sanitize($chat['message_content']);
			if($chat['from_uname'] == $_SESSION['username']) {
				$u = 1;
				$sespic = $picname;
			}else{
				$u = 2;
				$sespic = $picname2;
			}
# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
			$items .= <<<EOD
			{
				"s": "0",
				"sender": "{$chat['from_uname']}",
				"f": "{$_GET['client']}",
				"x": "{$chat['from_id']}",
				"p": "{$picname}",
				"p2": "{$picname2}",
				"st": "{$status}",
				"page": "{$_SESSION['chatpage']}",
				"pages": "{$pages}",
				"u": "{$u}",
				"mtype": "{$chat['message_type']}",
				"m": "{$chat['message_content']}"
			},
EOD;

			if (!isset($_SESSION['chatHistory'][$chat['from_uname']])) {
				$_SESSION['chatHistory'][$chat['from_uname']] = '';
			}

# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
			$_SESSION['chatHistory'][$chat['from_uname']] .= <<<EOD
			{
				"s": "0",
				"f": "{$chat['from_uname']}",
				"x": "{$chat['from_id']}",
				"p": "{$picname}",
				"p2": "{$picname2}",
				"spic": "{$sespic}",
				"st": "{$status}",
				"u": "{$u}",
				"mtype": "{$chat['message_type']}",
				"m": "{$chat['message_content']}"
			},
EOD;

			unset($_SESSION['tsChatBoxes'][$chat['from_uname']]);
			$_SESSION['openChatBoxes'][$chat['from_uname']] = $chat['message_date'];
		}
		if (!empty($_SESSION['openChatBoxes'])) {
			foreach ($_SESSION['openChatBoxes'] as $chatbox => $time) {
				if (!isset($_SESSION['tsChatBoxes'][$chatbox])) {
					$now = time()-strtotime($time);
					$time = date('g:iA M dS', strtotime($time));
					$message = "$time";
					if ($now > 180) {
# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
						$items .= <<<EOD
						{
							"s": "2",
							"f": "$chatbox",
							"x": "{$chat['from_id']}",
							"p": "{$picname}",
							"p2": "{$picname2}",
							"st": "{$status}",
							"m": "{$message}"
						},
EOD;
						if (!isset($_SESSION['chatHistory'][$chatbox])) {
							$_SESSION['chatHistory'][$chatbox] = '';
						}
# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
						$_SESSION['chatHistory'][$chatbox] .= <<<EOD
						{
							"s": "2",
							"f": "$chatbox",
							"x": "{$chat['from_id']}",
							"p": "{$picname}",
							"p2": "{$picname2}",
							"spic": "{$sespic}",
							"st": "{$status}",
							"m": "{$message}"
						},
EOD;
						$_SESSION['tsChatBoxes'][$chatbox] = 1;
					}
				}
			}
		}
		$sql = ("UPDATE WS_TPL.dbo.WS_Messages SET recd = 1 WHERE to_uname = '".escData($_SESSION["username"])."' AND recd = 0");
		$query = odbc_exec($cxn,$sql);
		if ($items != '') {
			$items = substr($items, 0, -1);
		}
		header('Content-type: application/json');?>{
			"items": [<?php echo $items;?>]
		}<?php
		exit(0);
	}
?>