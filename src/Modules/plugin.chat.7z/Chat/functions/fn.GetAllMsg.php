<?php
	function get_all_msg() {
		global $cxn;
		$perPage = 10;
		$sql = ("SELECT *
				 FROM WS_TPL.dbo.WS_Messages
				 WHERE to_uname = ?
				 AND from_uname = ?
				 OR to_uname = ?
				 AND from_uname = ?
				 ORDER BY message_id DESC");
		$stmt = odbc_prepare($cxn,$sql);
		$args = array(escData($_SESSION["username"]),escData($_GET["client"]),escData($_GET["client"]),escData($_SESSION["username"]));
		$res = odbc_execute($stmt,$args);

		$page = 1;
		if(!empty($_GET["page"])) {$_SESSION['chatpage'] = $page = $_GET["page"];}

		$start = ($page-1)*$perPage;
		if($start < 0) $start = 0;

		$query =  $stmt."limit".$start.",".$perPage; 

 		$query = odbc_execute($query);

		if(empty($_GET["rowcount"])) {
			$_GET["rowcount"] = $rowcount = odbc_num_rows(odbc_exec($stmt));
		}

		$pages  = ceil($_GET["rowcount"]/$perPage);

		$chatBoxes = array();
		$items = '';
		if(!empty($query)) {}

		while ($chat = odbc_fetch_array($query)) {
			$picname = "";
			$picname2 = "";
			$query1 = ("SELECT picname,online FROM WS_TPL.dbo.WS_UserData WHERE UserID = '".($chat['from_uname'])."'");

			$query_result = odbc_exec($cxn,$query1) OR error(odbc_errormsg());
			while ($info = odbc_fetch_array($query_result)) {
				$picname = "small".$info['picname'];
				$status = $info['online'];
			}
			$query4 = ("SELECT picname,online FROM WS_TPL.dbo.WS_UserData WHERE UserID = '".($chat['to_uname']). "'");

			$query_result4 = odbc_exec($cxn,$query4) OR error(odbc_errormsg());
			while ($info4 = odbc_fetch_array($query_result4)) {
				$picname2 = "small".$info4['picname'];
			}
			if($picname == "small"){
				$picname = "avatar_default.png";
			}
			if($picname2 == "small"){
				$picname2 = "avatar_default.png";
			}
			if($status == "0"){
				$status = "Offline";
			}else{
				$status = "Online";
			}

			if (!isset($_SESSION['openChatBoxes'][$_GET['client']]) && isset($_SESSION['chatHistory'][$_GET['client']])) {
				$items = $_SESSION['chatHistory'][$_GET['client']];
			}

			$chat['message_content'] = sanitize($chat['message_content']);

			if($chat['from_uname'] == $_SESSION['username']) {
				$u = 1;
				$sespic = $picname;
			}else{
				$u = 2;	
				$sespic = $picname2;
			}
# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
			$items .= <<<EOD
			{
				"s": "0",
				"sender": "{$chat['from_uname']}",
				"f": "{$_GET['client']}",
				"x": "{$chat['from_id']}",
				"p": "{$picname}",
				"p2": "{$picname2}",
				"st": "{$status}",
				"page": "{$_SESSION['chatpage']}",
				"pages": "{$pages}",
				"u": "{$u}",
				"mtype": "{$chat['message_type']}",
				"m": "{$chat['message_content']}"
			},
EOD;

			if (!isset($_SESSION['chatHistory'][$_GET['client']])) {
				$_SESSION['chatHistory'][$_GET['client']] = '';
			}

# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
			$_SESSION['chatHistory'][$_GET['client']] .= <<<EOD
			{
				"s": "0",
				"sender": "{$chat['from_uname']}",
				"f": "{$_GET['client']}",
				"x": "{$chat['from_id']}",
				"p": "{$picname}",
				"p2": "{$picname2}",
				"spic": "{$sespic}",
				"st": "{$status}",
				"page": "{$_SESSION['chatpage']}",
				"pages": "{$pages}",
				"u": "{$u}",
				"mtype": "{$chat['message_type']}",
				"m": "{$chat['message_content']}"
			},
EOD;

			unset($_SESSION['tsChatBoxes'][$_GET['client']]);
			$_SESSION['openChatBoxes'][$_GET['client']] = $chat['message_date'];
		}

		if (!empty($_SESSION['openChatBoxes'])) {
			foreach ($_SESSION['openChatBoxes'] as $chatbox => $time) {
				if (!isset($_SESSION['tsChatBoxes'][$chatbox])) {
					$now = time()-strtotime($time);
					$time = date('g:iA M dS', strtotime($time));

					$message = "$time";
					if ($now > 180) {
# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
						$items .= <<<EOD
						{
							"s": "2",
							"sender": "{$chat['from_uname']}",
							"f": "$chatbox",
							"x": "{$chat['from_id']}",
							"p": "{$picname}",
							"p2": "{$picname2}",
							"st": "{$status}",
							"page": "{$_SESSION['chatpage']}",
							"pages": "{$pages}",
							"m": "{$message}"
						},
EOD;

						if (!isset($_SESSION['chatHistory'][$chatbox])) {
							$_SESSION['chatHistory'][$chatbox] = '';
						}

# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
						$_SESSION['chatHistory'][$chatbox] .= <<<EOD
						{
							"s": "2",
							"sender": "{$chat['from_uname']}",
							"f": "$chatbox",
							"x": "{$chat['from_id']}",
							"p": "{$picname}",
							"p2": "{$picname2}",
							"spic": "{$sespic}",
							"st": "{$status}",
							"page": "{$_SESSION['chatpage']}",
							"pages": "{$pages}",
							"m": "{$message}"
						},
EOD;
						$_SESSION['tsChatBoxes'][$chatbox] = 1;
					}
				}
			}
		}
		$sql = ("UPDATE WS_TPL.dbo.WS_Messages SET recd = 1 WHERE to_uname = '".escData($_SESSION["username"])."' AND recd = 0");
		$query = odbc_exec($cxn,$sql);

		if ($items != '') {
			$items = substr($items, 0, -1);
		}

		header('Content-type: application/json');?>{
			"items": [<?php echo $items;?>]
		}
		<?php exit(0);
	}
?>