<?php
	function sendChat() {
		$from = $_SESSION['username'];
		$to = $_POST['to'];
		$to_id = $_POST['toid'];
		$from_id = $_SESSION['id'];
		$message = $_POST['message'];
		$_SESSION['openChatBoxes'][$_POST['to']] = date('Y-m-d H:i:s', time());
		$messagesan = sanitize($message);
		if (!isset($_SESSION['chatHistory'][$_POST['to']])) {
			$_SESSION['chatHistory'][$_POST['to']] = '';
		}
		$picname = "";
		$picname2 = "";
		$query1 = "SELECT picname,online 
				   FROM userdata 
				   WHERE username='" .mysql_real_escape_string($to). "' LIMIT 1";
		$query_result = mysql_query ($query1) OR error(mysql_error());
		while ($info = mysql_fetch_array($query_result)) {
			$picname = "small".$info['picname'];
			$status = $info['online'];
		}
		$query4 = "SELECT picname 
				   FROM userdata 
				   WHERE username='" .mysql_real_escape_string($_SESSION['username']). "' LIMIT 1";
		$query_result4 = mysql_query ($query4) OR error(mysql_error());
		while ($info4 = mysql_fetch_array($query_result4)) {
			$picname2 = "small".$info4['picname'];
		}
		if($picname == "small"){
			$picname = "avatar_default.png";
		}
		if($picname2 == "small"){
			$picname2 = "avatar_default.png";
		}
		if($status == "0"){
			$status = "Offline";
		}else{
			$status = "Online";
		}

# T_START_HEREDOC string - DO NOT EDIT
# Line placement MUST stay intact
		$_SESSION['chatHistory'][$_POST['to']] .= <<<EOD
		{
			"s": "1",
			"f": "{$to}",
			"x": "{$to_id}",
			"p": "{$picname}",
			"p2": "{$picname2}",
			"st": "{$status}",
			"m": "{$messagesan}"
		},
EOD;
		unset($_SESSION['tsChatBoxes'][$_POST['to']]);
		$sql = "insert into messages 
			(from_uname,to_uname,from_id,to_id,message_content,message_date) 
				values 
			('".mysql_real_escape_string($from)."', '".mysql_real_escape_string($to)."','".mysql_real_escape_string($from_id)."','".mysql_real_escape_string($to_id)."','".mysql_real_escape_string($message)."',NOW())";
		$query = mysql_query($sql);
		$res = mysql_query("UPDATE `userdata` SET online=1, last_active_timestamp = NOW() WHERE id = {$_SESSION['id']};");
		echo "1";
		exit(0);
	}
?>