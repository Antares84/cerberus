<?php
	function closeChat() {
		unset($_SESSION['openChatBoxes'][$_POST['chatbox']]);
		echo "1";
		exit(0);
	}
?>