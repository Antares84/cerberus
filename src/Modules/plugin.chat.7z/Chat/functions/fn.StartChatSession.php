<?php
	function startChatSession() {
		$items = '';
		if (!empty($_SESSION['openChatBoxes'])) {
			foreach ($_SESSION['openChatBoxes'] as $chatbox => $void) {
				$items .= chatBoxSession($chatbox);
			}
		}
		if ($items != '') {
			$items = substr($items, 0, -1);
		}
		header('Content-type: application/json');?>{
			"username": "<?php echo $_SESSION['uuid'];?>",
			"items": [<?php echo $items;?>]
		}<?php
		exit(0);
	}
?>