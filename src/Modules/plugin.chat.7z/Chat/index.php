<?php
	require_once('config.php');

	if(!isset($_SESSION['uuid'])) {
		$_SESSION['uuid']="1";
	}

	$query1 = ('SELECT * FROM WS_TPL.dbo.WS_UserData WHERE UserUID = ?');
	$stmt = odbc_prepare($cxn1,$query1);
	$args = array($_SESSION["uuid"]);
	$res1 = odbc_execute($stmt,$args);
	while($row1 = odbc_fetch_array($stmt)){
		$string = $row1["UserID"];
		$sesuserpic = $row1["picname"];
	}
#	echo "String: ".$string."<br />";
#	echo "User Pic: ".$sesuserpic."<br />";
#	die();

	if($sesuserpic == ""){
		$sesuserpic = "avatar_default.png";
	}

	# Stylesheets
	echo '<link type="text/css" rel="stylesheet" media="all" href="Chat/chatcss/chat-light.css" />';
	echo '<link type="text/css" rel="stylesheet" media="all" href="Chat/chatcss/chat.css" />';
	echo '<link type="text/css" rel="stylesheet" media="all" href="Chat/chatcss/screen.css" />';

#	echo '<link href="Chat/user_interface_kit/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">';

	# May not be needed - test
	echo '<script src="Chat/user_interface_kit/js/jquery-1.11.0.min.js"></script>';

#	<!-- Custom Theme files -->
	echo '<link href="Chat/user_interface_kit/css/style.css" rel="stylesheet" type="text/css" media="all"/>';

	// Initialize Plugin
	?>
	<script>
		var jQuery1111 = jQuery.noConflict();
		window.jQuery = jQuery1111;
	</script>
	<?php
#	echo '<script type="text/javascript" src="Chat/chatjs/init.js"></script>';
	echo '<script type="text/javascript" src="Chat/chatjs/jquery.js"></script>';
	echo '<script type="text/javascript" src="Chat/chatjs/chat.js"></script>';
	echo '<div id="drupalchat-wrapper">';
		echo '<div id="drupalchat" style="">';
			echo '<div class="item-list" id="chatbox_chatlist">';
				echo '<ul id="mainpanel">';
					echo '<li id="chatpanel" class="first last">';
						echo '<div class="subpanel" style="display: block;">';
							echo '<div class="subpanel_title" onclick="javascript:toggleChatBoxGrowth('chatlist')" >Chat<span class="options"></span>';
								echo '<span class="min localhost-icon-minus-1"><i class="fa fa-minus-circle minusicon text-20" aria-hidden="true"></i></span>';
							echo '</div>';
							echo '<div>';
								echo '<div class="chat_options" style="background-color: #eceff1;" >';
									echo '<div class="drupalchat-self-profile">';
										echo '<div class="drupalchat-self-profile-div">';
											echo '<div class="drupalchat-self-profile-img + localhost-avatar-sprite-28 "'.strtoupper($string[0]).'"_3">';
												if(!empty($row1['picname'])) {
													echo '<img src="storage/user_image/small"'.$row1['picname'].'""/>';
												}
											echo '</div>';
										echo '</div>';
										echo '<div class="drupalchat-self-profile-namdiv">';
											echo '<a class="drupalchat-profile-un drupalchat_cng">'.$string.'</a>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
								echo '<div class="drupalchat_search_main chatboxinput" style="background:#f9f9f9">';
									echo '<div class="drupalchat_search" style="height:30px;">';
										echo '<input class="drupalchat_searchinput live-search-box" placeholder="Type here to search" value="" size="24" type="text">';
										echo '<input class="searchbutton" value="" style="height:30px;border:none;margin:0px; padding-right:13px; vertical-align: middle;" type="submit">';
									echo '</div>';
								echo '</div>';
								echo '<div class="contact-list chatboxcontent">';
									echo '<ul class="live-search-list">';
										$query = ("SELECT * FROM WS_TPL.dbo.WS_UserData WHERE UserUID != ? AND online != 0 ORDER BY UserUID DESC");
										$stmt = odbc_prepare($cxn1,$query);
										$args = array($_SESSION["uuid"]);
										$res_a = odbc_execute($stmt,$args);
										while ($row = odbc_fetch_array($stmt)) {
											$id = $row["UserUID"];
											$username = $row["UserID"];
											$picname = $row["picname"];
											$res = odbc_exec($cxn1,"SELECT * FROM WS_TPL.dbo.WS_UserData WHERE UserUID = '".$id."' AND DATEDIFF(mi, last_active_timestamp, getdate()) > 1;");
											if($res === FALSE) {
												die(odbc_errormsg()); // TODO: better error handling
											}
											$num = odbc_num_rows($res);
											if($num == "0"){
												$onofst = "Online";
											}else{
												$onofst = "Offline";
											}
										echo '<li class="iflychat-olist-item iflychat-ol-ul-user-img iflychat-userlist-room-item chat_options">';
										echo '<div class="drupalchat-self-profile">';
											echo '<span title="'.$onofst.'" class="'.$onofst.'statuso" style="text-align: right">';
												echo '<span class="statusIN">';
													echo '<i class="fa fa-circle" aria-hidden="true"></i>';
												echo '</span>';
											echo '</span>';
											echo '<div class="drupalchat-self-profile-div">';
												echo '<div class="drupalchat-self-profile-img + localhost-avatar-sprite-28 '.strtoupper($username[0]).'_3">';
													if(!empty($row['picname'])) {
														echo '<img src="storage/user_image/small'.$row['picname'].'"/>';
													}
												echo '</div>';
											echo '</div>';
											echo '<div class="drupalchat-self-profile-namdiv">';
												echo '<a class="drupalchat-profile-un drupalchat_cng" href="javascript:void(0)" onclick="javascript:chatWith('.$username.','.$id.','.$sesuserpic.','.$onofst.')">'.$username.'</a>';
											echo '</div>';
										echo '</div>';
									echo '</li>';
									}
									echo '</ul>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</li>';
				echo '</ul>';
			echo '</div>';
		echo '</div>';
	echo '</div>';
?>
	<script type="text/javascript">
		function scrollDown2(chatboxtitle){
			var wtf    = jQuery1111("#chatbox_"+chatboxtitle+" .chatboxcontent");
			var height = wtf[0].scrollHeight;
			wtf.scrollTop(height);
		}
		function uploadimage(touname) {
			var file_name=jQuery1111("#chatbox_"+touname+" #imageInput").val();
			var fileName = jQuery1111("#chatbox_"+touname+" #imageInput").val();
			var fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1);

			var toid = jQuery1111("#chatbox_"+touname+" #to_id").val();
			var tun = jQuery1111("#chatbox_"+touname+" #to_uname").val();
			var fun = jQuery1111("#chatbox_"+touname+" #from_uname").val();

			var base_url = 'process.php?toid='+toid+'&tun='+tun+'&fun='+fun;
			var file_data=jQuery1111("#chatbox_"+touname+" #imageInput").prop("files")[0];
			var form_data=new FormData();
			form_data.append("file",file_data);

			jQuery1111.ajax({
				type:"POST",
				url: base_url,
				cache:false,
				contentType:false,
				processData:false,
				data:form_data,
				success:function(data){
					//alert(data);
					jQuery1111.each(data.items, function(i,item){
						if (item) { // fix strange ie bug
							chatboxtitle = item.chatboxtitle;
							filename = item.filename;
							path = item.path;
							//jQuery1111('#loadmsg').hide();
							var message_content = "<a href='"+path+"'><img src='"+filename+"' style='max-width:156px;min-height:100px;padding: 4px 0 4px 0; border-radius: 7px;'/></a>";
//							jQuery1111("#chatbox_"+chatboxtitle).append('<div class="bubble me">'+message_content+'</div>');
							jQuery1111("#chatbox_"+chatboxtitle+" .chatboxcontent").append('<div class="chatboxmessage direct-chat-msg right"><div class="direct-chat-info clearfix"><span class="direct-chat-name pull-right">'+item.sender+'</span></div><img class="direct-chat-img" src="storage/user_image/'+img+'" alt="message user image"><span class="direct-chat-text">'+message_content+'</span></div>');
						}
						setTimeout(scrollDown2(chatboxtitle), 5000);
					});
				},
				error:function(){}
			});
		}
	</script>
	<script>
		jQuery(document).ready(function(){
			jQuery1111('.live-search-list li').each(function(){
				jQuery1111(this).attr('data-search-term', jQuery1111(this).text().toLowerCase());
			});
			jQuery1111('.live-search-box').on('keyup', function(){
				var searchTerm = jQuery1111(this).val().toLowerCase();
				jQuery1111('.live-search-list li').each(function(){
					if (jQuery1111(this).filter('[data-search-term *= ' + searchTerm + ']').length > 0 || searchTerm.length < 1) {
						jQuery1111(this).show();
					}else{
						jQuery1111(this).hide();
					}
				});
			});
		});
	</script>