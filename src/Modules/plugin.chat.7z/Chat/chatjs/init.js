// Initialize Plugin
var jQuery1111 = jQuery.noConflict();
window.jQuery = jQuery1111;