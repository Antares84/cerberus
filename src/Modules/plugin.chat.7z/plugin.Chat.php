<?php
#	if ($dir = opendir('./')) {
#		$blacklist = array('.', '..', 'somedir', 'plugins.autoload.php');
#		while (false !== ($content = readdir($dir))) {
#			if (!in_array($content, $blacklist)) {
#				echo "$content\n";
#				foreach(glob($content. DIRECTORY_SEPARATOR ."index.php") as $plugin){include $plugin;}
#			}
#		}
#		closedir($dir);
#	}

#	echo "Plugin Dir: ".$plugin."<br />";

	# Post $Config var data in an array
	$cfg=array();
	
	$cfg["WS_Chat"]=__DIR__ . DIRECTORY_SEPARATOR ."Chat" . DIRECTORY_SEPARATOR;
	require_once($cfg["WS_Chat"]."index.php");

#	echo "DIR: ".$cfg["WS_Chat"]."<br />";
?>