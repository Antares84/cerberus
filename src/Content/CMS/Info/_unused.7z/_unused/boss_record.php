<?php
# Start ObCache	
	ob_start();
# Login Check
	if(!($user -> LoggedIn())){header("Location:".$CMS_Home."?p=home");die();}
# Content
	echo '<div id="content-wrapper">';
		echo '<div id="title">Boss Record</div>';
		echo '<div id="content">';
			echo '<table cellpadding="0" cellspacing="0" class="pro-table">';
				echo '<tr>';
#					echo '<th>#</th>';
					echo '<th>Boss Name</th>';
					echo '<th>Victorious Character</th>';
					echo '<th>Map #</th>';
					echo '<th>Time of Death</th>';
				echo '</tr>';
#				$count = 1;
				$sql=("SELECT TOP 20 Text1,Text2,Text3,MapID,ActionTime FROM ".$CMS_Shaiya_GameLog.".dbo.".$CMS_Shaiya_ActionLog." WHERE ActionType='173' AND Text2='death' ORDER BY row DESC");
				$res=odbc_exec($dbConn,$sql);
				while($getInfo = odbc_fetch_array($res)) {
					$text1 = $getInfo['Text1'];
					$text3 = $getInfo['Text3'];
					$mapid = $getInfo['MapID'];
					$actiontime = Date("m/d/y h:i A", strtotime($getInfo['ActionTime']));
					echo '<tr>';
#						echo '<th>'.$count.'</th>';
						echo '<td>'.$text1.'</td>';
						echo '<td>'.$text3.'</td>';
						echo '<td>'.$mapid.'</td>';
						echo '<td>'.$actiontime.'</td>';
					echo '</tr>';
#					$count++;
				}
			echo '</table>';
		echo '</div>';
	echo '</div>';
?>