<?php
// Site Security
	if (!defined('CMS_Secure'))
	{
		die('Direct access not allowed.');
	}
?>
<div id="content-wrapper">
	<div id="content-title">
		<span class="servername"><?php echo $ServerName;?></span> Drop List
	</div>
	<div id="content">
	<div id="content-h3">Notice:</div>
		<p class="content-box">
			Please note that "Trash" drops have not been removed as some of these are enchant items. Enchant Items that are not listed on the drop list drop in the same areas as on OS.
		</p>
	<div id="content-h3">Cornwells Ruin/Argilla Ruins</div>
		<div id="content-h4">Normal Mobs</div>
			<p class="content-box">
				Noble Lv. 1-15 Gear
			</p>
	<div id="content-h3">Proelium</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Recreation Rune, Dual Lapis, Lv5 Lapis
			</p>
		<div id="content-h4">Ravenous Rabbit</div>
			<p class="content-box">
				Lv. 15 Capes, Worship Accessories, Lv. 15 Helmets
			</p>
	<div id="content-h3">Cloron's Lair/Fantasma's Lair</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Dual Lapis
			</p>
		<div id="content-h4">Dragon</div>
			<p class="content-box">
				Lv. 54 Weps, 250 DP Voucher
			</p>
	<div id="content-h3">Cantabilian</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Recreation Rune, Dual Lapis, Lv5 Lapis
			</p>
		<div id="content-h4">Ez'tuk Kul</div>
			<p class="content-box">
				30 Capes, Heroic Accessories, Dread 30 Gear
			</p>
	<div id="content-h3">20-30 Dungeon</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lvl 30 Heroic Gear
			</p>
		<div id="content-h4">Corrupt Paros/Duplicated Rapioru</div>
			<p class="content-box">
				Lvl 30 Dread Helmet/Gauntlet/Boots, Heroic Accessories
			</p>
	<div id="content-h3">Cryptic Throne</div>
		<div id="content-h4">Haruhion/Freezing Mirage</div>
			<p class="content-box">
				Lvl 50 Goddess Weapons
			</p>
		<div id="content-h4">Bosses</div>
			<p class="content-box">
				53 Goddess (No Helmets) , 56 Weps
			</p>
		<div id="content-h4">Cryptic One</div>
			<p class="content-box">
				Lvl 53 Goddess Gear with Helmets
			</p>
		<div id="content-h4">Cryptic The Immortal</div>
			<p class="content-box">
				Lvl 60 Cape, Lvl 53 Goddess Gear with Helmets, Lvl 59 Weapons, Lv60 Weapons
			</p>
	<div id="content-h3">Cave of Stigma/Aurizen Ruin</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lv5 lapis
			</p>
		<div id="content-h4">Bosses</div>
			<p class="content-box">
				Lv6 lapis, Lv5 lapis
			</p>
	<div id="content-h3">Pando / Lan</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lvl 45 Pre-Ele weps
			</p>
	<div id="content-h3">D-Water</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lvl 49 Legendary Weps, Gertine Stone, Rand Stone, Dragonite Stone
			</p>
	<div id="content-h3">Sky City</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lvl 54 weps (legendary), DP Vouchers
			</p>
		<div id="content-h4">Boxes</div>
			<p class="content-box">
				DP Vouchers
			</p>
		<div id="content-h4">Ele Altars</div>
			<p class="content-box">
				Lvl 54 Goddess Weapons
			</p>
		<div id="content-h4">Seraphim</div>
			<p class="content-box">
				Goddess Accessories, Ele 1, 100 dp voucher
			</p>
	<div id="content-h3">D1</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lvl 53 Legendary Gear with Helmets, Helmet Lapis
			</p>
		<div id="content-h4">Loca & Lich</div>
			<p class="content-box">
				Flash Lapis Lv1, Sonic Lapis Lv2
			</p>
	<div id="content-h3">D2</div>
		<div id="content-h4">Mini Bosses</div>
			<p class="content-box">
				Flash Lapis Lv1, Sonic Lapis Lv2
			</p>
		<div id="content-h4">Kimu</div>
			<p class="content-box">
				Goddess Accessories, Ele 1, 100 dp voucher
			</p>
	<div id="content-h3">DD1</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Rec Runes, Dual Lapis
			</p>
		<div id="content-h4">Mini Bosses</div>
			<p class="content-box">
				Lvl 58 Legendary Helmets
			</p>
	<div id="content-h3">DD2</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Accessory Lapis, Operator's Exclusive, Lvl 58 Legendary Gauntlets
			</p>
		<div id="content-h4">Mini Bosses</div>
			<p class="content-box">
				Lvl 58 Legendary Pants, Operator's Exclusive, Accessory Lapis
			</p>
	<div id="content-h3">Jungle</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Dual Lapis, Lvl 58 Legendary Boots
			</p>
		<div id="content-h4">Trolls & Helltooth</div>
			<p class="content-box">
				Dual Lapis, Power Lapisia, Lvl 54 Capes, Lvl 58 Legendary Boots
			</p>
		<div id="content-h4">Mini Bosses</div>
			<p class="content-box">
				Lvl 58 Legendary Tops
			</p>
	<div id="content-h3">Caellum Sacra</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Legendary Accessories
			</p>
		<div id="content-h4">Sacra Royal Guardians (Floor 3)</div>
			<p class="content-box">
				Lvl 54 Goddess Weapons
			</p>
		<div id="content-h4">Dios</div>
			<p class="content-box">
				Ele 1, Perfect Linking Hammer, Goddess Accessories
			</p>
	<div id="content-h3">Oblivion Insula</div>
		<div id="content-h4">All Mobs</div>
			<p class="content-box">
				Lvl 6 lapis
			</p>
		<div id="content-h4">Bosses</div>
			<p class="content-box">
				Lvl 6 Lapis
			</p>
		<div id="content-h4">Forni/Mr.Vei/Porci/Evil Midget Clavi</div>
			<p class="content-box">
				Flash Ring, Lvl 6 Lapis
			</p>
	<div id="content-h3">Guild Ranking Battle</div>
		<div id="content-h4">Mobs</div>
			<p class="content-box">
				1-100 Etin Coins
			</p>
		<div id="content-h4">Sirvana, Kahlion, Silvanus, Pantera</div>
			<p class="content-box">
				100 Etin Coins
			</p>
		<div id="content-h4">Ephilios and Old Willow</div>
			<p class="content-box">
				1000 Etin Coins, S H A I Y A leters (see forum post for details) 
			</p>
	</div>
</div>