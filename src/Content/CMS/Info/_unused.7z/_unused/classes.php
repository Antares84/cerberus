<?php
	echo '<div id="content-wrapper">';
		echo '<div id="title">The Playable Character Classes of <span class="servername">'.WS_Title.'</span></div>';
		echo '<div id="content">';
			echo '<div id="tabs">';
				echo '<ul>';
					echo '<li><a href="#tabs-1">Human</a></li>';
					echo '<li><a href="#tabs-2">Elf</a></li>';
					echo '<li><a href="#tabs-3">Nordein</a></li>';
					echo '<li><a href="#tabs-4">Vail</a></li>';
				echo '</ul>';
				echo '<div id="tabs-1">';
# Human
					echo '<div id="tabs2-h">';
						echo '<ul>';
							echo '<li><a href="#tabs2-1">Fighter</a></li>';
							echo '<li><a href="#tabs2-2">Defender</a></li>';
							echo '<li><a href="#tabs2-3">Priest</a></li>';
						echo '</ul>';
						echo '<div id="tabs2-1">';
							echo '<h3>Fighter</h3>';
							echo '<p class="content-box">';
								echo 'The Fighter is a fierce melee combatant, confronting foes up close and personal. Physical attack power is the focus of the Fighter, but don’t be fooled - a certain amount of magical points (MP) is needed to power the Fighter’s devastating special skills.';
							echo '</p>';
							echo '<h3>Fighter Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Wide range of available weapons.<br />';
								echo '- Powerful physical attacks.<br />';
								echo '- Front-line brawler.<br />';
								echo '- Automatically gains Strength (+1 STR) per level.<br />';
							echo '</p>';
						echo '</div>';# end tabs2-1
						echo '<div id="tabs2-2">';
							echo '<h3>Defender</h3>';
							echo '<p class="content-box">';
								echo 'The Defender is a hard-as-nails tank. Defenders have high stamina and high hit points, enabling them to take a beating while dishing one out. Unlike Fighters, Defenders can take on multiple foes at the same time with little worry. Defenders also have the ability to provoke enemies into attacking them, a useful skill when adventuring in groups.';
							echo '</p>';
							echo '<h3>Defender Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Uses shields, one-handed swords, and blunt weapons.<br />';
								echo '- High vitality and stamina.<br />';
								echo '- First into the fray.<br />';
								echo '- Automatically gains Health (+1 REC) per level.<br />';
							echo '</p>';
						echo '</div>';# end tabs2-2
						echo '<div id="tabs2-3">';
							echo '<h3>Priest</h3>';
							echo '<p class="content-box">';
								echo 'Relying on the spiritual nature of humans, the Priest is a true healer. The Priest uses healing magic to keep him/herself and party members healthy during battle. Priests can resurrect the dead, an extremely useful skill for keeping fallen comrades around in a tense situation. Priests also have a high resistance to magical attacks, making them a threat to Pagans.';
							echo '</p>';
							echo '<h3>Priest Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Curing powers.<br />';
								echo '- Ability to transform allies into powerful monsters.<br />';
								echo '- Ability to transform enemies into harmless animals.<br />';
								echo '- Automatically gains Wisdom (+1 WIS) per level.<br />';
							echo '</p>';
						echo '</div>';# end tabs2-3
					echo '</div>';# end tabs2
				echo '</div>';# end tabs-1
# Elf
				echo '<div id="tabs-2">';
					echo '<div id="tabs2-e">';
						echo '<ul>';
							echo '<li><a href="#tabs2-1">Archer</a></li>';
							echo '<li><a href="#tabs2-2">Mage</a></li>';
							echo '<li><a href="#tabs2-3">Ranger</a></li>';
						echo '</ul>';
						echo '<div id="tabs2-1">';
							echo '<h3>Archer</h3>';
							echo '<p class="content-box">';
								echo 'Striking from a distance helps keep Archers out of harm’s way. Archers use ranged attacks to wound and slow the enemy, as well as lower its attack power, or stop it in its tracks. Special skills of the Archer allow them to literally rain arrows down upon their targets. Archers also have Lady Luck smiling down on them, enabling them to make brutal critical hits.';
							echo '</p>';
							echo '<h3>Archer Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Uses bow, crossbow, javelin, and short swords.<br />';
								echo '- Distanced attacks.<br />';
								echo '- High accuracy.<br />';
								echo '- Automatically gains Fortune (+1 LUC) per level.<br />';
							echo '</p>';
						echo '</div>';# end tabs2-1
						echo '<div id="tabs2-2">';
							echo '<h3>Mage</h3>';
							echo '<p class="content-box">';
								echo 'One of the hallmarks of the Elf race is their use of magic. No other class so exemplifies this than the Mage. Attacking up close or far away, targeting one foe or many, the Mage uses the power of magic to destroy their enemies. Their ability to harness the power of fire, water, earth, and wind makes the Mage a force to be reckoned with.';
							echo '</p>';
							echo '<h3>Mage Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Awe-inspiring attacks.<br />';
								echo '- Single-target and area-of-effect attacks.<br />';
								echo '- Automatically gains Intelligence (+1 INT) per level.<br />';
							echo '</p>';
						echo '</div>';# end tabs2-2
						echo '<div id="tabs2-3">';
							echo '<h3>Ranger</h3>';
							echo '<p class="content-box">';
								echo 'The Ranger uses knowledge of the forest and the wilds to blend into his/her surroundings. Stealth and deception are trademarks of a good Ranger, while ambush and evasion are their staples in combat. They can also frighten beasts or disguise themselves as harmless creatures, further enabling their stealth.';
							echo '</p>';
							echo '<h3>Ranger Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Uses short blades and claw weapons.<br />';
								echo '- High evasion ability.<br />';
								echo '- Stealth and disguise.<br />';
								echo '- Automatically gains Dexterity (+1 DEX) per level.<br />';
							echo '</p>';
						echo '</div>';# end tabs2-3
					echo '</div>';# end tabs2
				echo '</div>';# end tabs-2
# Nordein
				echo '<div id="tabs-3">';
					echo '<div id="tabs2-n">';
						echo '<ul>';
							echo '<li><a href="#tabs2-1">Guardian</a></li>';
							echo '<li><a href="#tabs2-2">Hunter</a></li>';
							echo '<li><a href="#tabs2-3">Warrior</a></li>';
						echo '</ul>';
						echo '<div id="tabs2-1">';
							echo '<h3>Guardian</h3>';
							echo '<p class="content-box">';
								echo 'The Guardian is a defensive powerhouse, pure and simple. Guardians have high stamina and high hit points, enabling them to take a beating while returning in kind. Guardians can take on multiple foes at the same time with little worry. Guardians also have the ability to provoke enemies into attacking them, a useful skill when adventuring in groups.';
							echo '</p>';
							echo '<h3>Guardian Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Uses shields, one-handed swords, and blunt weapons.<br />';
								echo '- High vitality and stamina.<br />';
								echo '- First into the fray.<br />';
								echo '- Automatically gains Health (+1 REC) per level.<br />';
							echo '</p>';
						echo '</div>';# end of tabs2-1
						echo '<div id="tabs2-2">';
							echo '<h3>Hunter</h3>';
							echo '<p class="content-box">';
								echo 'Hunters use ranged attacks to wound and slow the enemy, as well as lower its attack power, or stop it dead in its tracks. Hunters keep their distance in battle and should stay away from the front lines. Their special skills allow them to literally rain death down upon their targets. Hunters also have high luck, enabling them to make critical hits more often than other classes.';
							echo '</p>';
							echo '<h3>Hunter Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Uses axes, javelins, and bows.<br />';
								echo '- Distanced attacks.<br />';
								echo '- High accuracy.<br />';
								echo '- Automatically gains Fortune (+1 LUC) per level.<br />';
							echo '</p>';
						echo '</div>';# end of tabs2-2
						echo '<div id="tabs2-3">';
							echo '<h3>Warrior</h3>';
							echo '<p class="content-box">';
								echo 'Like the Human Fighter, the Nordein Warrior is a fierce melee combatant, confronting foes up close and personal. Physical attack power is the focus of the Fighter, but don’t be fooled - a certain amount of magical points (MP) is required to power the Warrior’s devastating special skills.';
							echo '</p>';
							echo '<h3>Warrior Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Wide range of available weapons.<br />';
								echo '- Powerful physical attacks.<br />';
								echo '- Front-line brawler.<br />';
								echo '- Automatically gains Strength (+1 STR) per level.<br />';
							echo '</p>';
						echo '</div>';# end of tabs2-3
					echo '</div>';# end of tabs2
				echo '</div>';# end of tabs-3
# Vail
				echo '<div id="tabs-4">';
					echo '<div id="tabs2-v">';
						echo '<ul>';
							echo '<li><a href="#tabs2-1">Assassin</a></li>';
							echo '<li><a href="#tabs2-2">Oracle</a></li>';
							echo '<li><a href="#tabs2-3">Pagan</a></li>';
						echo '</ul>';
						echo '<div id="tabs2-1">';
							echo '<h3>Assassin</h3>';
							echo '<p class="content-box">';
								echo 'The Union’s answer to the Ranger is the Assassin. Stealth and deception are the trademarks of a good Assassin, while ambush and evasion are their staples in combat. They also can frighten beasts or disguise themselves as harmless creatures, further enabling their stealth.';
							echo '</p>';
							echo '<h3>Assassin Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Uses short blades and claw weapons.<br />';
								echo '- High evasion ability.<br />';
								echo '- Stealth and disguise.<br />';
								echo '- Automatically gains Dexterity (+1 DEX) per level.<br />';
							echo '</p>';
						echo '</div>';# end of tabs2-1
						echo '<div id="tabs2-2">';
							echo '<h3>Oracle</h3>';
							echo '<p class="content-box">';
								echo 'Like the Human Priest, the Oracle relies on the spiritual nature of the Vail to heal allies. They can resurrect the dead, an extremely useful skill for keeping fallen comrades around and a must when "Ultimate Difficulty" characters are in the party. Oracles also have a high resistance to magical attacks, making them a threat to Mages.';
							echo '</p>';
							echo '<h3>Oracle Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Curing powers.<br />';
								echo '- Ability to transform allies into powerful monsters.<br />';
								echo '- Ability to transform enemies into harmless animals.<br />';
								echo '- Automatically gains Wisdom (+1 WIS) per level.<br />';
							echo '</p>';
						echo '</div>';# end of tabs2-2
						echo '<div id="tabs2-3">';
							echo '<h3>Pagan</h3>';
							echo '<p class="content-box">';
								echo 'Channeling spiritual forces allows the Pagan to unleash powerful magic attacks. Attacking up close or far away, targeting one foe or many, the Pagan uses spiritual magic to destroy their enemies. Their ability to harness the natural elements of fire, water, earth, and wind makes Pagans a force to be reckoned with.';
							echo '</p>';
							echo '<h3>Pagan Characteristics</h3>';
							echo '<p class="content-box">';
								echo '- Awe-inspiring attacks.<br />';
								echo '- Single-target and area-of-effect attacks.<br />';
								echo '- Automatically gains Intelligence (+1 INT) per level.<br />';
							echo '</p>';
						echo '</div>';# end of tabs2-3
					echo '</div>';# end of tabs2
				echo '</div>';# end of tabs-4
			echo '</div>';# end of tabs
		echo '</div>';# end content
	echo '</div>';# end content-wrapper
?>