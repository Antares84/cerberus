<?php
	echo '<div id="content-wrapper">';
		echo '<div id="title">';
			echo '<span class="servername">'.$ServerName.'</span> Staff List';
		echo '</div>';
		echo '<div id="content">';
			echo '<h1 style="color:gold;">Admin</h1><br />';
			echo '<p class="content-box tac">';
				echo '<b>[ADM]Seraphim</b> - Admin, owner, developer';
			echo '</p>';
			echo '<h1 style="color:cyan;">Alliance of Light</h1><br />';
			echo '<p class="content-box tac">';
#				echo '<b>[GM]Slaughter</b><br />';
				echo '<b>[GM]RIAS</b>';
			echo '</p>';
			echo '<h1 style="color:red;">Union of Fury</h1><br />';
			echo '<p class="content-box tac">';
				echo '<b>[GM]EvilMe</b><br />';
				echo '<b>[GM]Frost</b>';
			echo '</p>';
		echo '</div>';
	echo '</div>';
?>