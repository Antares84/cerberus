<?php
	if($_SESSION["settings"]["Fieldsets"] == 1){
		echo '<div class="row content">';
			echo '<fieldset>';
				echo '<legend>SQL Scripts</legend>';
				echo 'Any SQL Scripts for MSSQL for Shaiya will be posted here. If you have one that you created, you can also have it posted here for others to use. All scripts added here have been updated and/or checked for any injection issues. If there\'s a script missing from here that you think should be here, it\'s either because I haven\'t found it yet, didn\'t believe it to be useful, or was a possible security risk. However, you may upload your own scripts to our file archive for consideration.<br><br>';

				echo 'Nexus Development reserves the right to refuse posting onscene or inappropriate content. If you believe our decision on a topic to be in error, you are welcome to send us a message detailing what you believe the error is and explain in detail.';
			echo '</fieldset>';
		echo '</div>';
	}else{
		echo '<div class="row content">';
			echo '<div class="title">SQL Scripts</div>';
			echo '<div class="inner">';
				echo 'Any SQL Scripts for MSSQL for Shaiya will be posted here. If you have one that you created, you can also have it posted here for others to use. All scripts added here have been updated and/or checked for any injection issues. If there\'s a script missing from here that you think should be here, it\'s either because I haven\'t found it yet, didn\'t believe it to be useful, or was a possible security risk. However, you may upload your own scripts to our file archive for consideration.<br><br>';

				echo 'Nexus Development reserves the right to refuse posting onscene or inappropriate content. If you believe our decision on a topic to be in error, you are welcome to send us a message detailing what you believe the error is and explain in detail.';
			echo '</div>';
		echo '</div>';
	}
?>