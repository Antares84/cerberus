<?php
	$data		=	'http://ndf-innovations.net/cms_versions.ini';
	$url_enc	=	urlsafe_b64encode($data);
	$url_dec	=	urlsafe_b64decode($url_enc);

	echo '<div class="row content">';
		echo '<fieldset>';
			echo '<legend>Base64</legend>';
			echo '<div class="row">';
				echo "URL Base: $data<br>";
				echo "URL Encoded: $url_enc<br>";
				echo "URL Decoded: $url_dec<br>";
			echo '</div>';
		echo '</fieldset>';
		
		echo '<fieldset>';
			echo '<legend>CMS Settings</legend>';
			echo '<div class="row">';
				echo getSettings($col='use_fieldsets').'<br>';
#				echo $cfg["settings"]
#				echo $cfg["settings"].getSettings();
#				echo getSettings();
			echo '</div>';
		echo '</fieldset>';

		echo '<fieldset>';
			echo '<legend>CMS Settings</legend>';
			echo '<div class="row">';
				echo 'Session Settings: <br>';
				print_r ($_SESSION["settings"]);
			echo '</div>';
		echo '</fieldset>';
	echo '</div>';