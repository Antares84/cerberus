<?php
	echo '<div class="container" style="border:1px solid red;max-height:600px;min-height:200px;">';
#		$db->listMyProperties();
#		$dsp->listMyProperties();
#		$msgs->listMyProperties();
#		$settings->listMyProperties();
		echo var_dump($msgs);
	echo '</div>';