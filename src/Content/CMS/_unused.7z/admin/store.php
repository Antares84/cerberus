<?php
	# Site Authorization
#	Auth();
	# Content
	echo '<link rel="stylesheet" href="'.$cfg["WS_ShopMenu"].'">';
	if(User::get_isAdmin()){
		echo '<script charset="utf-8" type="text/javascript" src="'.$cfg["CMS_JS"].'custom/shop-admin.js"></script>';
	}else{
		echo '<script charset="utf-8" type="text/javascript" src="'.$cfg["CMS_JS"].'custom/shop.js"></script>';
	}
	if( !isset($_GET['cat']) ){
		$index = 0;
	}else{
		$index = $_GET['cat'];
	}

	echo '<div class="row hide">';
		echo '<div id="ShopMenu">';
			echo '<div id="cssmenu">';
				echo '<ul>';
					$catnames=array("Discounts","Armor","Clothing","Enchancers","Misc","Tools","Weapons");
					for($i=0;$i<count($catnames);$i++){
						echo '<li><a href="?page='.$cfg["Page_Index"].'&cat='.($i+1).'">'.$catnames[$i].'</a></li>';
					}
				echo '</ul>';
			echo '</div>';
		echo '</div>';
		echo '<div id="ShopData" style="border: 1px solid lime;">';
			if($index > 0){
				$sql = ("SELECT * FROM EU_Stores.dbo.EU_Items WHERE ItemIndex = ?");
				$stmt = odbc_prepare($cxn1,$sql);
				$args = array($index);
				$res = odbc_execute($stmt,$args);
				if(odbc_num_rows($stmt) > 0) {
					while($data = odbc_fetch_array($stmt)){
						echo '<div id="ItemContainer">';
							echo '<div id="Prod">';
								echo '<div id="ProdHeader" class="tac">';
									echo '<div class="ProdName" title="'.$data['ItemName'].'">'.$data['ItemName'].'</div>';
									if(User::get_isAdmin()){echo '<a class="display_button" href="./admin/remove_product.php?ind='.$index.'&code=" style="padding: 2px;">Remove Product</a>';}
								echo '</div>';
								echo '<div id="ProdDetail">';
									echo '<table class="ProdTable tac">';
										echo '<tr>';
											echo '<th>Price</th>';
											echo '<th>TTVal</th>';
											echo '<th>MU</th>';
										echo '</tr>';
										echo '<tr>';
											echo '<td>'.$data['Val'].'</td>';
											echo '<td>'.$data['TTVal'].'</td>';
											echo '<td>'.$data['MU'].'</td>';
										echo '</tr>';
									echo '</table>';
								echo '</div>';
							echo "</div>";
						echo "</div>";
					}
				}else{echo '<div class="tac">No items were found for this category.<br />Please choose a different category.</div>';}
			}else{
				echo '<div class="tac">Choose an option from the menu on the left to see what items are available from the vendor of this shop.</div>';
			}
		echo '</div>';
#		echo $url.'<br />';
#		echo PageURI.'<br />';
#		echo PageClass.'<br />';
#		echo $testurl;
#		echo $index;
#		if($ChkUser->isAdmin()){echo '<a class="display_button" href="admin.php" >Add Product</a>';}
	echo '</div>';
?>