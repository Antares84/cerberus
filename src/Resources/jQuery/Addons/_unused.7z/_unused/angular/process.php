<?php
	# Arrays ======================================================================
	$cfg			= array(); # array to hold configuration details
	$errors         = array(); # array to hold validation errors
	$data 			= array(); # array to pass back data

	$cfg['FTW_SECURE'] = true;
	require_once('../../config/cfg.db.php');
	$CustInfo = 'FTW_DB.dbo.FTW_CustInfo';

	# Validators ==================================================================
	# Validate First Name
	if(empty($_POST['sales_code'])){$_POST['sales_code'] = '';}
	if(empty($_POST['first_name'])){$errors['first_name'] = 'Please provide your first name';}
	# Validate Last Name
	if(empty($_POST['last_name'])){$errors['last_name'] = 'Please provide your last name';}
	# Validate address_1
	if(empty($_POST['address_1'])){$errors['address_1'] = 'Please provide your registered address.';}
	if(empty($_POST['address_2'])){$_POST['address_2'] = '';}
	# Validate Phone_1
	if(empty($_POST['phone_1'])){$errors['phone_1'] = 'Please provide your phone number so that we can contact you.';}
	if(empty($_POST['phone_2'])){$_POST['phone_2'] = '';}
	# Validate City
	if(empty($_POST['city'])){$errors['city'] = 'Please provide your city.';}
	# Validate state
	if(empty($_POST['state'])){$errors['state'] = 'Please provide your state.';}
	# Validate zip
	if(empty($_POST['zip'])){$errors['zip'] = 'Please provide your zipcode.';}
	# Validate E-Mail
	if(empty($_POST['e_mail'])){$errors["e_mail"]='Please provide your email.';}
	elseif(!filter_var($_POST['e_mail'],FILTER_VALIDATE_EMAIL)){$errors["e_mail"]='Invalid email format';}
	# Validate Motorcycle Make
	if(empty($_POST['mot_make'])){$errors['mot_make']='Please provide your motorcycle make.';}
	# Validate Motorcycle Model
	if(empty($_POST['mot_model'])){$errors['mot_model']='Please provide your motorcycle model.';}
	# Validate Motorcycle Year
	if(empty($_POST['mot_year'])){$errors['mot_year']='Please provide your motorcycle year.';}
	# Validate Motorcycle VIN
	if(empty($_POST['mot_vin'])){
		#$errors['mot_vin']='Please provide your motorcycle VIN.';
		$_POST['mot_vin'] = '';
	}
	# Validate Motorcycle Odometer
	if(empty($_POST['mot_odometer'])){$errors['mot_odometer']='Please provide your motorcycle odometer.';}
	# Validate Warranty Options
	if(empty($_POST['mot_warr_opt'])){$errors['mot_warr_opt']='Please select a warranty option.';}
	# Validate Credit Card Number
#	if(empty($_POST['cc_number'])){$errors['cc_number']='Please provide a credit card number.';}
	# Validate Credit Card Expiration Date
#	if(empty($_POST['cc_exp_date'])){$errors['cc_exp_date']='Please provide the expiration date for the credit card you have chosen to use.';}
	# Validate Credit Card CV2 Number
#	if(empty($_POST['cc_cv2'])){$errors['cc_cv2']='Please provide the CV2 number located on the back of your credit card.';}
	if(empty($_POST['sales_comment'])){$_POST['sales_comment'] = '';}

	# return a response ===========================================================
	if(!empty($errors)) {
		# if there are items in our errors array, return those errors
		$data['success'] = false;
		$data['errors']  = $errors;
	}else{
		# Insert Into Customer Information Table
		$sql = "INSERT INTO ".$CustInfo."
			(
				SalesCode,
				FirstName,
				LastName,
				Phone1,
				Phone2,
				Address1,
				Address2,
				City,
				State,
				ZipCode,
				Email,
				VehMake,
				VehModel,
				VehYear,
				VehOdometer,
				VehVIN,
				WarrOpt,
				Comment
			)
		VALUES
			(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		";
		$stmt = odbc_prepare($cxn,$sql);
		$args = array($_POST['sales_code'],$_POST['first_name'],$_POST['last_name'],$_POST['phone_1'],$_POST['phone_2'],$_POST['address_1'],$_POST['address_2'],$_POST['city'],$_POST['state'],$_POST['zip'],$_POST['e_mail'],$_POST['mot_make'],$_POST['mot_model'],$_POST['mot_year'],$_POST['mot_odometer'],$_POST['mot_vin'],$_POST['mot_warr_opt'],$_POST['sales_comment']);
#		$args = array($_POST['sales_code'],$_POST['first_name'],$_POST['last_name'],$_POST['phone_1'],$_POST['phone_2'],$_POST['address_1'],$_POST['address_2'],$_POST['city'],$_POST['state'],$_POST['zip'],$_POST['e_mail'],$_POST['mot_make'],$_POST['mot_model'],$_POST['mot_year'],$_POST['mot_odometer'],$_POST['mot_vin'],$_POST['mot_warr_opt'],$_POST['cc_number'],$_POST['cc_exp_date'],$_POST['cc_cv2'],$_POST['sales_comment']);
		if(odbc_execute($stmt,$args)){
			# if there are no errors, return a message
			$data['success'] = true;
			$data['message'] .= 'Thank you, '.$_POST['first_name'].', for your interest in purchasing a warranty from us.';

			# Send Registration E-Mail
			$mail_for = "register";
			require_once("mail.php");
			if($mail->Send()) {
				$data['message'] .= "We have recieved your request, and one of our helpful sales associates will be contacting you shortly to go over your request and answer any questions that you may have.<br>";
				#$data['message'] .= "Please check your mail to complete registration.<br />";
				#$data['message'] .= "If the email is not in your main inbox please check your spam folder or disable spam filtering.<br />";
				#$data['message'] .= "didnt recieve an email? please try to resend the email. Click <a href=".$emailaddy.">Here.</a><br />";
				#	$data['message'] .= "Your activation key is: ".$activationKey."<br />";
			}
			else{
				$data['errors'] = "Validation email failed to send. Contact an administrator.";
			}
		}
	}

	# return all our data to an AJAX call
	echo json_encode($data);
?>