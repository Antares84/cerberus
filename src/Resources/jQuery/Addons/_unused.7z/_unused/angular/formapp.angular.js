// define angular module/app
var formApp = angular.module('formApp', []);

// create angular controller and pass in $scope and $http
function formController($scope, $http) {
	// create a blank object to hold our form information
	// $scope will allow this to pass between controller and view
	$scope.formData = {};
	// process the form
	$scope.processForm = function() {
		$http({
			method  : 'POST',
			url     : 'assets/jQuery/angularjs/process.php',
			data    : $.param($scope.formData),
			headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
		})
		.success(function(data){
			console.log(data);
			if(!data.success){
				// if not successful, bind errors to error variables
				// Personal Info
				$scope.errorfirst_name		=	data.errors.first_name;
				$scope.errorlast_name		=	data.errors.last_name;
				$scope.errorphone_1			=	data.errors.phone_1;
				$scope.erroraddress_1		=	data.errors.address_1;
				$scope.errorcity			=	data.errors.city;
				$scope.errorstate			=	data.errors.state;
				$scope.errorzip				=	data.errors.zip;
				$scope.errore_mail			=	data.errors.e_mail;

				// Motorcycle Info
				$scope.errormot_make		=	data.errors.mot_make;
				$scope.errormot_model		=	data.errors.mot_model;
				$scope.errormot_year		=	data.errors.mot_year;
				$scope.errormot_vin			=	data.errors.mot_vin;
				$scope.errormot_odometer	=	data.errors.mot_odometer;

				// Warranty Options
				$scope.errormot_warr_opt	=	data.errors.mot_warr_opt;

				// Credit Card Info
//				$scope.errorcc_number		=	data.errors.cc_number;
//				$scope.errorcc_exp_date		=	data.errors.cc_exp_date;
//				$scope.errorcc_cv2			=	data.errors.cc_cv2;

				// Comment Block
				$scope.errorsales_comment	=	data.errors.sales_comment;
			}
			else{
				// if successful, bind success message to message
				// Personal Info
				$scope.message				=	data.message;
				$scope.errorfirst_name		=	'';
				$scope.errorlast_name		=	'';
				$scope.errorphone_1			=	'';
				$scope.erroraddress_1		=	'';
				$scope.errorcity			=	'';
				$scope.errorstate			=	'';
				$scope.errorzip				=	'';
				$scope.errore_mail			=	'';

				// Motorcycle Info
				$scope.errormot_make		=	'';
				$scope.errormot_model		=	'';
				$scope.errormot_year		=	'';
				$scope.errormot_vin			=	'';
				$scope.errormot_odometer	=	'';

				// Warranty Options
				$scope.errormot_warr_opt	=	'';

				// Credit Card Informantion
//				$scope.errorcc_number 		=	'';
//				$scope.errorcc_exp_date		=	'';
//				$scope.errorcc_cv2 			=	'';

				// Comment Block
				$scope.errorsales_comment	=	'';
			}
		});
	};
}