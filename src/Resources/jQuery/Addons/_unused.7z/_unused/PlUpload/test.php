<?php
	echo 'test verified<br>';
	echo __DIR__.'<br>';
?>