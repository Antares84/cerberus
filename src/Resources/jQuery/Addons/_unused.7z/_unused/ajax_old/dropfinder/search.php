<?php
	require_once('../Autoloader.class.php');
	$db		=	new Database();
	$Select	=	new Select();

#	echo '<pre>';
#		echo var_dump($_POST);
#	echo '</pre>';
#	die();

	echo '<form class="search">';
		echo '<div class="form-group row">';
			echo '<label for="Input-Item" class="col-sm-5 col-form-label tar">Item Name</label>';
			echo '<div class="col-sm-4">';
				echo '<div class="input-group">';
					echo '<div class="input-group-addon"><i class="fa fa-info-circle"></i></div>';
					echo '<input class="form-control" id="Item" name="Item" type="text" value="" placeholder="Item Name"/>';
				echo '</div>';
			echo '</div>';
		echo '</div>';

		echo '<div class="form-group row">';
			echo '<div class="col-sm-6"></div>';
			echo '<button class="btn btn-sm btn-primary open_modal"  data-target="#plugin_modal" data-toggle="modal"><i class="fa fa-search"></i> Search</button>';
		echo '</div>';

	echo '</form>';
?>
<script>
	$(document).ready(function(){
		$("button#open_modal").click(function(){
			$.ajax({
				type: "POST",
				url: '<?php echo $this->get_PLUGINS_DIR();?>DropFinder/search_submit.php',
				data: $('form.search').serialize(),
				success: function(message){
					$('#settings_modal #dynamic-content').html(message);
//					$("#TableLoader").load(location.href + " #TabularData");
				},
				error: function(){
					alert("Error");
				}
			});
		});
	});
</script>