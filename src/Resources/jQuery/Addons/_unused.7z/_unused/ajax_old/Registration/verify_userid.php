<?php
	require_once('../Autoloader.php');

	$Browser	=	new Browser();
	$db			=	new Database();
	$Data		=	new Data($db);
	$Setting	=	new Setting($db);
	$User		=	new User($Browser,$Data,$db,$Setting);

	if($Setting->DEBUG === "1" || $Setting->DEBUG === "2"){
		echo '<pre>';
			echo var_dump($_POST);
		echo '</pre>';

		if($Setting->DEBUG === "2"){
			die();
		}
	}

	echo '<form>';
		echo '<div class="form-group row">';
			echo '<div class="col-sm-4"></div>';
			echo '<div class="col-sm-4">';
				echo '<div class="input-group">';
					echo '<input class="form-control" id="UserID" name="UserID" type="text" value="'.$_POST["UserID"].'" readonly/>';
				echo '</div>';
			echo '</div>';
		echo '</div>';

		echo '<button type="button" class="btn btn-primary center-block" id="verify"><i class="fa fa-check-circle"></i> Check Availability</button>';
	echo '</form>';
?>
<script>
	$(document).ready(function(){
		$("button#verify").click(function(){
			$.ajax({
				type: "POST",
				url: "ajax/Registration/verify_userid_submit.php",
				data: $('form').serialize(),
				success: function(message){
					$('#verify_userid_modal #dynamic-content').html(message);
				},
				error: function(){
					alert("Error");
				}
			});
		});
	});
</script>