<?php
	require_once('../Autoloader.php');

	$Browser	=	new Browser();
	$db			=	new Database();
	$Data		=	new Data($db);
	$Setting	=	new Setting($db);
	$User		=	new User($Browser,$Data,$db,$Setting);

	if($Setting->DEBUG === "1" || $Setting->DEBUG === "2"){
		echo '<pre>';
			echo var_dump($_POST);
		echo '</pre>';

		if($Setting->DEBUG === "2"){
			die();
		}
	}

	if(isset($_POST["UserID"])){
		$sql	=	('
						SELECT TOP 1 DisplayName
						FROM '.$db->get_TABLE("USER_DATA").'
						WHERE DisplayName=?'
		);
		$stmt	=	odbc_prepare($db->conn,$sql);
		$args	=	array($_POST["DisplayName"]);
		$prep	=	odbc_execute($stmt,$args);

		if($prep){
			if(odbc_num_rows($stmt) === 0){
				echo '<button class="btn btn-success btn-lg center-block"><i class="fa fa-info-circle"></i> '.$_POST["DisplayName"].' is available!</button>';
			}
			else{
				echo '<button class="btn btn-danger btn-lg center-block"><i class="fa fa-info-circle"></i> '.$_POST["DisplayName"].' is already taken. Please choose a different DisplayName.</button>';
			}
		}
	}
?>