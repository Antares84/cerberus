<?php
	# Launch Object & Session Cache
	session_start();
	ob_start();

	require_once('../Autoloader.php');

	$Browser	=	new Browser();
	$db			=	new Database();
	$Data		=	new Data($db);
	$Setting	=	new Setting($db);
	$User		=	new User($Browser,$Data,$db,$Setting);
	$Layout		=	new Layout($db);
	$Style		=	new Style($db,$Layout);
	$Messenger	=	new Messenger($User,$Browser);

	if(!isset($_SESSION["MESSAGES"])){
		$_SESSION["MESSAGES"] = $Messenger->Init_Messenger();
	}

	if($Setting->DEBUG === "1" || $Setting->DEBUG === "2"){
		echo '<pre>';
			echo var_dump($_POST);
		echo '</pre>';

		if($Setting->DEBUG === "2"){
			die();
		}
	}

	if(isset($_POST['UserID']) && !empty($_POST['UserID'])){
		$username	=	isset($_POST['UserID'])	?	$Data->escData(trim($_POST['UserID']))	:	"";
		$password	=	isset($_POST['Pw'])		?	$Data->escData(trim($_POST['Pw']))		:	"";

		if(empty($username) || $username == "") {
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x01';
		}
		elseif(strlen($username) < 3 || strlen($username) > 16 ){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x02';
		}
		elseif(ctype_alnum($username) === false){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x03';
		}

		# Check For Password Field Population
		if(empty($password)){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x04';
		}
		elseif(strlen($password) < 3 || strlen($password) > 16){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x05';
		}
		elseif(ctype_alnum($password) === false){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x06';
		}
		if(count($_SESSION["MESSAGES"]['type']) == 0){
			$sql	=	("SELECT * FROM ".$db->get_TABLE('USER_DATA')." WHERE UserID=? AND Pw=?");
			$stmt	=	odbc_prepare($db->conn,$sql);
			$args	=	array($username,$password);
			$prep	=	odbc_execute($stmt,$args);
			if($prep){
				if($userInfo = odbc_fetch_array($stmt)){
					if($userInfo["Status"] >= 0){
						session_name("CMS_SESS_VALIDATED");

#						$_SESSION["UUID"]			=	$userInfo["UserUID"];
#						$_SESSION["UID"]			=	$userInfo["UserID"];
#						$_SESSION["Status"]			=	$userInfo["Status"];
#						$_SESSION["AdminLevel"]		=	$userInfo["AdminLevel"];
#						$_SESSION["Email"]			=	$userInfo["Email"];
#						$_SESSION["CMS_SID"]		=	$this->Session->createSession($userInfo["UserID"]);
#						$this->Session->sessStore('Logged In - UserID/Pw Access for '.$username.' from '.$this->Browser->UserIP);
						echo '<button class="btn btn-success btn-lg" style="width:100%;"><i class="fa fa-info-circle"></i> Account successfully validated.</button>';
						header('location: ?'.$Setting->PAGE_PREFIX.'=Auth&Valid=true');
#						header('Refresh:0;url=?'.$Setting->PAGE_PREFIX.'=Auth&Valid=true');
					}

					# Acct locked by admin
					if($userInfo['Status'] < 0){
						$_SESSION["MESSAGES"]["type"][].='0';
						$_SESSION["MESSAGES"]["body"][].='L-0x07';
#						sessStore("Login attempt failed on banned account for $username from $UserIP.");
					}
					else{
						$_SESSION["MESSAGES"]["type"][].='3';
						$_SESSION["MESSAGES"]["body"][].='L-0x08';
					}
				}
				else{
					$_SESSION["MESSAGES"]["type"][].='0';
					$_SESSION["MESSAGES"]["body"][].='L-0x09';
				}
			}
			else{
				echo '<button class="btn btn-danger btn-lg" style="width:100%;"><i class="fa fa-info-circle"></i> Setting update failed.</button>';
			}
		}
	}
	else{
		echo 'No submission data found!<br>';
		echo 'Are you sure that you filled out the form?';
	}

	echo '<form class="edit_setting">';
		echo '<button type="button" class="btn btn-primary center-block" id="edit_setting"><i class="fa fa-check-circle"></i> Update Setting</button>';
	echo '</form>';
?>
<script>
	$(document).ready(function(){
		$("button#edit_setting").click(function(){
			$.ajax({
				type: "POST",
				url: "./<?php echo $Style->get_JQUERY_ADDONS_DIR();?>ajax/Auth/auth_redir.php",
				data: $('form.edit_setting').serialize(),
				success: function(message){
					$('#auth_modal #dynamic-content').html(message);
					window.location.reload(true);
				},
				error: function(){
					alert("Error");
				}
			});
		});
	});
</script>