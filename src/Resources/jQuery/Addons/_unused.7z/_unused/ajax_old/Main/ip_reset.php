<?php
	require_once('../Autoloader.php');

	$Browser	=	new Browser();
	$db			=	new Database();
	$Data		=	new Data($db);
	$Setting	=	new Setting($db);
	$User		=	new User($Browser,$Data,$db,$Setting);

	if($Setting->DEBUG === "1" || $Setting->DEBUG === "2"){
		echo '<pre>';
			echo var_dump($_POST);
		echo '</pre>';

		if($Setting->DEBUG === "2"){
#			die();
		}
	}

	list($Column,$UserIP) = explode("~",$_POST['id']);

	echo '<form class="edit_setting">';
		echo '<input class="form-control" id="Column" name="Column" type="hidden" value="'.$Column.'"/>';
		echo '<input class="form-control" id="UserIP" name="UserIP" type="hidden" value="'.$UserIP.'"/>';

		echo '<div class="form-group row">';
			echo '<label for="Input-Value" class="col-sm-4 col-form-label tar">MemberID</label>';
			echo '<div class="col-sm-8">';
				echo '<div class="input-group">';
					echo '<div class="input-group-addon"><i class="fa fa-info-circle"></i></div>';
					echo '<input class="form-control" id="Value" name="Value" type="text" placeholder="Enter Your Member ID"/>';
				echo '</div>';
			echo '</div>';
		echo '</div>';

		echo '<button type="button" class="btn btn-primary center-block" id="edit_setting"><i class="fa fa-check-circle"></i> Update Setting</button>';
	echo '</form>';
?>
<script>
	$(document).ready(function(){
		$("button#edit_setting").click(function(){
			$.ajax({
				type: "POST",
				url: "ajax/Main/ip_reset_submit.php",
				data: $('form.edit_setting').serialize(),
				success: function(message){
					$('#acct_reset_modal #dynamic-content').html(message);
					window.location.reload(true);
				},
				error: function(){
					alert("Error");
				}
			});
		});
	});
</script>