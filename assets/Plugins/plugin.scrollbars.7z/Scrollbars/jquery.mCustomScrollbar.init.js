// mCustomScrollbar Initialization
(function($){
	$(window).on("load",function(){
		$(".scroll").mCustomScrollbar();//{
//			theme:"minimal"
//			theme:"3d-thick-dark"
//		});
	});
//	$(window).on("load",function(){
//		$("body").mCustomScrollbar();
//	});
})(jQuery);