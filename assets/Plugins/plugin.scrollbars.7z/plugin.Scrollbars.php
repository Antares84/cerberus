<?php
	if(file_exists($cfg["WS_Scrollbars_Loc"].'jquery.mCustomScrollbar.concat.min.js')){
		echo '<script type="application/javascript" src="'.$cfg["WS_Scrollbars_Loc"].'jquery.mCustomScrollbar.concat.min.js"></script>';
	}else{
		echo 'Failed to load jquery.mCustomScrollbar.concat.min.js';
	}
	if(file_exists($cfg["WS_Scrollbars_Loc"].'jquery.mCustomScrollbar.js')){
		echo '<script type="application/javascript" src="'.$cfg["WS_Scrollbars_Loc"].'jquery.mCustomScrollbar.js"></script>';
	}else{
		echo 'Failed to load '.$cfg["WS_Scrollbars_Loc"].'jquery.mCustomScrollbar.js';
	}
?>