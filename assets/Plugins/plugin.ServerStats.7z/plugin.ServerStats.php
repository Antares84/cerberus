<?php
	if(file_exists($cfg["PLUGIN_SERVERSTATS_LOC"].'serverstats.php')){
		include_once($cfg["PLUGIN_SERVERSTATS_LOC"].'serverstats.php');
	}else{
		echo 'ServerStats plugin not found!';
	}
?>