<?php
	$Title	=	NULL;
	$Body	=	NULL;

	# CONTENT
	$Title	.=	'Current Time (EST - GMT +5)';
	$Body	.=	'<span id="servertime"></span><br>';
	$Body	.=	'<span id="serverdate">'.date('m/d/y').'</span>';

	echo $this->ds_card(
						$Title,
						'tac',
						$Body,
						''
	);
?>