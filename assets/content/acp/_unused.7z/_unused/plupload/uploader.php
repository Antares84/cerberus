<?php
	echo '<div id="wrapper">';
		echo '<div id="page-wrapper">';
			echo '<div class="container-fluid">';
				echo '<div class="row">';
					echo '<div class="col-lg-12">';
						echo '<h1 class="page-header">'.$cfg["PageTitle"];if(!empty($cfg["PageSub"])){echo '<small> - '.$cfg["PageSub"].'</small>';}echo '</h1>';
						echo '<div id="title" class="tac">Menu Editor</div>';
						echo '<div id="content-wrapper">';
							echo '<div id="content">';
								echo '<h1>Custom example</h1>';
								echo '<p>Shows you how to use the core plupload API.</p>';
								echo '<div id="filelist">Your browser doesn\'t have Flash, Silverlight or HTML5 support.</div>';
								echo '<br />';
								echo '<div id="container">';
									echo '<a id="pickfiles" href="javascript:;">[Select Files To Upload]</a>';
									echo '<br><br>';
									echo '<a id="uploadfiles" href="javascript:;">[Begin Upload]</a>';
								echo '</div>';
								echo '<br />';
								echo '<pre id="console"></pre>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</div>';
	echo '</div>';

	# PlUpload
	echo '<script charset="utf-8" type="text/javascript" src="'.$cfg["SkinjQuery"].'PlUpload/plupload.full.min.js"></script>';
	echo '<script src="'.$cfg["SkinjQuery"].'PlUpload/init.plupload.js"></script>';
?>