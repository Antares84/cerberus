<?php
	# CONTENT
	echo '<div class="row">';
		echo '<div class="col-lg-12">';
			$this->TitleBar("badge-secondary","Tools");
			$this->Select->Color();
		echo '</div>';
	echo '</div>';