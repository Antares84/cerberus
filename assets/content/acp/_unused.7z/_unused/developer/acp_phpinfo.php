<?php
	echo '<div id="wrapper">';
		echo '<div id="page-wrapper">';
			echo '<div class="container-fluid">';
				#<!-- Page Heading -->
				echo '<div class="row">';
					echo '<div class="col-xl-12">';
						echo '<h1 class="page-header">Bootstrap Grid</h1>';
						echo '<ol class="breadcrumb">';
							echo '<li><i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a></li>';
							echo '<li class="active"><i class="fa fa-wrench"></i> Bootstrap Grid</li>';
						echo '</ol>';
					echo '</div>';
				echo '</div>';
				
				echo '<div class="row">';
					echo '<div class="container>';
						phpinfo();
					echo '</div>';
				echo '</div>';

			echo '</div>';
		echo '</div>';
	echo '</div>';
?>