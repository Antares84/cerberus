<?php
	echo '<div id="wrapper">';
		echo '<div id="page-wrapper">';
			echo '<div class="container-fluid">';
				#<!-- Page Heading -->
				echo '<div class="row">';
					echo '<div class="col-xl-12">';
						echo '<h1 class="page-header">Bootstrap Grid</h1>';
						echo '<ol class="breadcrumb">';
							echo '<li><i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a></li>';
							echo '<li class="active"><i class="fa fa-wrench"></i> Bootstrap Grid</li>';
						echo '</ol>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-12 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-12</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-6 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-6</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-6 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-6</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-4 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-4</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-4 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-4</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-4 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-4</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-3 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-3</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-3 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-3</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-3 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-3</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-3 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-3</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-2 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-2</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-2 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-2</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-2 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-2</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-2 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-2</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-2 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-2</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-2 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-2</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-1 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-1</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-8 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-8</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-4 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-4</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->

				echo '<div class="row">';
					echo '<div class="col-xl-3 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-3</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-6 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-6</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="col-xl-3 text-xs-center">';
						echo '<div class="card card-default">';
							echo '<div class="card-block">.col-xl-3</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
				#<!-- /.row -->
			echo '</div>';
			#<!-- /.container-fluid -->
		echo '</div>';
		#<!-- /#page-wrapper -->
	echo '</div>';
	#<!-- /#wrapper -->