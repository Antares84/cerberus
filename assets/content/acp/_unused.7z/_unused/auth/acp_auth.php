<?php
	if(isset($_POST["submit_login"]) && !empty($_POST["submit_login"])){
		# Load Messenger Array
		if(isset($_SESSION["MESSAGES"])){
			unset($_SESSION["MESSAGES"]);
			$_SESSION["MESSAGES"] = $this->Messenger->Init();
		}elseif(!isset($_SESSION["MESSAGES"])){
			$_SESSION["MESSAGES"] = $this->Messenger->Init();
		}
		# Check For Username Field Population
		$username	=	isset($_POST["username"])	?	$this->Data->escData(trim($_POST["username"]))	:	'';
		$password	=	isset($_POST["password"])	?	$this->Data->escData(trim($_POST["password"]))	:	'';

		if(empty($username) || $username == ""){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x01';
		}elseif(strlen($username) < 3 || strlen($username) > 16 ){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x02';
		}elseif(ctype_alnum($username) === false){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x03';
		}
		# Check For Password Field Population
		if(empty($password)){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x04';
		}elseif(strlen($password) < 3 || strlen($password) > 16){
			$_SESSION["MESSAGES"]["type"][].='0';
			$_SESSION["MESSAGES"]["body"][].='L-0x05';
		}
		# If No Errors | Continue
		if(count($_SESSION["MESSAGES"]['type']) == 0){
			# Check if username already exists in the database.
			$sql	=	("SELECT * FROM ".$this->db->get_table('SH_USERDATA')." WHERE UserID=? AND PwPlain=?");
			$stmt	=	odbc_prepare($this->db->conn,$sql);
			$args	=	array($username,$password);
			$prep	=	odbc_execute($stmt,$args);
			if($prep){
				if($userInfo = odbc_fetch_array($stmt)){
					if($userInfo["Status"] == 16 || $userInfo["Status"] == 32 || $userInfo["Status"] == 64 || $userInfo["Status"] == 80){
						# Set a session name
						session_name("CMS_SESSION");
						# Start The session
						@session_start();
						# Set a session cookie (Required for some browsers, as settings that had been done before are not very effective)
						setcookie(session_name(), session_id(), time()+3600*24*365, "/");
						# Set Session Values
						$_SESSION["UserUID"]		=	$userInfo["UserUID"];
						$_SESSION["UserID"]			=	$userInfo["UserID"];
						$_SESSION["AdminLevel"]		=	$userInfo["Status"];
						$_SESSION["SID"]			=	$this->Session->CREATE_SESSION($userInfo["UserID"]);
						$_SESSION["LoginTime"] 		=	time();
						$_SESSION["LoggedIn"]		=	true;

						$_SESSION["MESSAGES"]["type"][].='3';
						$_SESSION["MESSAGES"]["body"][].='L-0x08';

						header('Refresh:0;url=?'.$this->Setting->PAGE_PREFIX.'=DASHBOARD');
					}
					elseif($userInfo["AdminLevel"] == 0){
						# Acct locked by admin
						$_SESSION["MESSAGES"]["type"][].='0';
						$_SESSION["MESSAGES"]["body"][].='L-0x07';
					}
				}else{
					$_SESSION["MESSAGES"]["type"][].='0';
					$_SESSION["MESSAGES"]["body"][].='L-0x09';
				}
			}else{
				$_SESSION["MESSAGES"]["type"][].='0';
				$_SESSION["MESSAGES"]["body"][].='L-0x10';
			}
		}
	}
	else{
		echo '<div class="container sb_container">';
			echo '<form class="acp_login_form" action="" method="POST">';
				echo '<h1><span>Staff</span> Login</h1>';
				echo '<div class="inset">';
					echo '<p>';
						echo '<label for="email">ADMIN ID</label>';
						echo '<input type="text" name="username" class="tac" placeholder="AdminID">';
					echo '</p>';
					echo '<p>';
						echo '<label for="password">PASSWORD</label>';
						echo '<input type="password" name="password" class="tac" placeholder="Password">';
					echo '</p>';
				echo '</div>';
				echo '<p class="p-container">';
#					echo '<span><a href="#">Forgot password ?</a></span>';
					echo '<input type="submit" name="submit_login" value="Login">';
				echo '</p>';
			echo '</form>';
		echo '</div>';
	}
?>