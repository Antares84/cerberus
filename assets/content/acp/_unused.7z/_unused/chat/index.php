<?php
	# Box
	echo "<div class=\"container\">";
		echo "<div class=\"row-fluid grid-set\">";
			echo "<div class=\"span6\">";
				echo "<div class=\"box\">";
					echo "<div class=\"header\">";
						echo "<h4>Your Own Box</h4>";
					echo "</div>";
					echo "<div class=\"content pad margin-reset\">";
						echo "<h5 align=\"center\" style=\"color: #555\">Your own content, your own admin template style. Some elements are courtesy of <a href=\"http://themeforest.net/item/curve-admin-template/5817114?ref=pauloreg\">Curve Admin Template</a></h5>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
			#<!-- Chat/Messages Box -->
			echo "<div class=\"span6\">";
				echo "<div class=\"box\">";
					echo "<div class=\"header\">";
						echo "<h4>Chat/Messages Sample</h4>";
					echo "</div>";

					echo "<div class=\"content\">";
					#	Please Note: 
					#	Users avatars must be formatted like this: "userX" where "X" is the user ID, if you don"t like check documentation for more info.
						echo "<table class=\"table table-condensed margin-reset\">";
							echo "<tbody>";
								foreach($chat->get_users($chat->clientID) as $user) {
									$user_id		=	$_SESSION["uuid"];
									$user_name		=	$_SESSION["uid"];
									$status			=	$user["status"];
									$new_message	=	$chat->get_unread_messages($user_id, $chat->clientID);

									if($new_message == 0){
										$message_appender = "";
									}
									else{
										$message_appender = " <span class=\"badge badge-info\">".$new_message."</span>";	
									}

									$session = $user["session"];
									if($session == "online"){
										$session_appender = "<span class=\"label label-success\">".$session."</label>";
									}
									else{
										$session_appender = "<span class=\"label label-important\">".$session."</label>";
									}
									echo "<tr>";
										echo "<td>";
											echo "<a href=\"chat.php?id=".$user_id."\"><img src=\"images/avatars/user$user_id.png\" /></a>";
										echo "</td>";
										echo "<td>";
											echo "<a href=\"chat.php?id=$user_id\"><span class=\"userNames\">".ucfirst($user_name)."</span></a>$message_appender<br><span class=\"status\">$status</span>";
										echo "</td>";
										echo "<td><span class=\"on-row\">".$session_appender."</span></td>";
									echo "</tr>";
								}
							echo "</tbody>";
						echo "</table>";
					echo "</div>";
					#echo $chat->get_users($_SESSION["uid"]);
					echo $chat->clientID;
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</div>";
?>