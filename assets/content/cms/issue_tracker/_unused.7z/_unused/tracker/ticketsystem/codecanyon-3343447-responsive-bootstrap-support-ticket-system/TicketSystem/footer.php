<?php if(@$isLogin and $userinfo->role == "user"): ?>

<hr style="margin-top:0px;">
<footer class="pager" style="bottom:0px;">
        <p><?php echo FOOTER;?></p>
</footer>
</body>
</html>
<?php endif;?>