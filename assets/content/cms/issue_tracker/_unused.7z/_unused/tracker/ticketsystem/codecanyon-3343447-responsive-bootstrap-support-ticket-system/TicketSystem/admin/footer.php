<?php if(@$isLogin and $userinfo->role == "admin"): ?>
<hr>
<footer class="pager" style="bottom:0px;">
        <p><?php echo FOOTER; ?></p>
</footer>

</body>
</html>
<?php endif;?>