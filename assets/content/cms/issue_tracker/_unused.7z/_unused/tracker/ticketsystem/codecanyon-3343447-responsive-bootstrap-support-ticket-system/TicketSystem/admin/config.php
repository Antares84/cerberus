<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "databasepass");
define("DB_NAME", "databasename");

//First page edit

define("SITE_TITLE", "Your site title");
define("DESCRIPTION_TITLE", "Description title part...");
define("DESCRIPTION", "Description part...");
define("FOOTER", "� Your footer text");
?>